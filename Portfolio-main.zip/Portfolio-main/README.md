<h1>:blue_car: <a href="https://ymatheusvieira.vercel.app/"> Portfólio </a></h1>

<div style="display: inline_block">

<img src="https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white" />
<img src="https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white" />
<img src="https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E" />
  
  
  
</div>

<img src ="https://cdn.discordapp.com/attachments/908101448112431115/964901539942662224/unknown.png" />

<div style="display: inline_block">
  
<a href = "mailto:ymatheusvieira.contato@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
<a href="https://www.linkedin.com/in/ymatheus-vieira/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>
<a href="https://ymatheusvieira.vercel.app/" target="_blank"><img src="https://img.shields.io/badge/-Portf%C3%B3lio-brown?style=for-the-badge&logo=true" target="_blank"></a>
  
</div>

<h2>:bookmark_tabs: Descrição</h2>
<p>Meu portfólio. Aplicação criada para mostrar os projetos que irei desenvolver durante minha carreira.</p>



<h2>:hammer: Créditos</h2>
<table>
  <tr>
    <td align="center">
      <a href="https://github.com/Math-Vieira">
        <img src="https://cdn.discordapp.com/attachments/908101448112431115/964905499613077504/me.png" width="100px;" alt="Foto do Matheus Vieira"/><br>
        <sub>
          <b>Matheus Vieira</b>
        </sub>
      </a>
    </td>
  </tr>
</table>

<h2>:dollar: Licença</h2>
<b>Proibida a utilização dos arquivos para fins diferentes de aprendizado.</b>
